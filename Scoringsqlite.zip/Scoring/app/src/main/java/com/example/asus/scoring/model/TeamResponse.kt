package com.example.asus.scoring.model

data class TeamResponse(val teams:List<Team>)