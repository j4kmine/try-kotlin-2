package com.example.asus.scoring.model

data class EventResponse(val events:List<Event>)